// // src/api/maintenance.js
// import api from "./api";

// export const getMaintenanceRecords = async () =>
//   (await api.get("/maintenance")).data;

// export const addMaintenance = async (data) =>
//   (await api.post("/maintenance", data)).data;

// export const updateMaintenance = async (id, data) =>
//   (await api.put(`/maintenance/${id}`, data)).data;

// export const deleteMaintenance = async (id) =>
//   (await api.delete(`/maintenance/${id}`)).data;
