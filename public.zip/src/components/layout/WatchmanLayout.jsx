import DashboardLayout from "./DashboardLayout";
export default function WatchmanLayout() {
  return <DashboardLayout role="WATCHMAN" />;
}