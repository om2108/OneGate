import React from "react";
import DashboardLayout from "./DashboardLayout";

export default function OwnerLayout() {
  return <DashboardLayout role="OWNER" />;
}
