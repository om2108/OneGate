import DashboardLayout from "./DashboardLayout";
export default function MemberLayout() {
  return <DashboardLayout role="MEMBER" />;
}