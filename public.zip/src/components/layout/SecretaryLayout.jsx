import DashboardLayout from "./DashboardLayout";
export default function SecretaryLayout() {
  return <DashboardLayout role="SECRETARY" />;
}