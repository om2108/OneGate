import DashboardLayout from "./DashboardLayout";
export default function UserLayout() {
  return <DashboardLayout role="USER" />;
}